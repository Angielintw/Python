#Input Function
print( len( input("What is your name?")))
print(len (input ("What is your mother's name?")))